import 'dart:convert';

import 'package:http/http.dart' as http;
void postOperation(
  String education,
  String joiningYear,
  String city,
  String paymentTier,
  String age,
  String gender,
  String everBenched,
  String experidnce,
) async {
  final url =
      Uri.http("127.0.0.1:41432", "/predict"); // Adjust the URL path accordingly
  await http.post(
    url,
    headers: {"Content-Type": "application/json"},
    body: jsonEncode({
      "Education": education,
      "JoiningYear": int.parse(joiningYear),
      "City": city,
      "PaymentTier": int.parse(paymentTier),
      "Age": int.parse(age),
      "Gender": gender,
      "EverBenched": everBenched,
      "ExperienceInCurrentDomain": experidnce, // Corrected variable name
    }),
  );
}
