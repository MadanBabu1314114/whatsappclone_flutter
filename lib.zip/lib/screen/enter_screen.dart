import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:jcsirhelloworld/backend/post_operation.dart';
import 'package:jcsirhelloworld/data/data.dart';

class EnterScreen extends StatefulWidget {
  const EnterScreen({super.key});

  @override
  State<EnterScreen> createState() => _EnterScreenState();
}

class _EnterScreenState extends State<EnterScreen> {
  var selectedEducation;

  var selectedJoiningYear;

  var selectCity;

  var selectdPaymeneties;

  final enteredAge = TextEditingController();

  var selectedGender;

  var seletedEverBenched;

  final enterExperience = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ML Model "),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text("Enter your all the details Correctly"),
              Form(
                  child: Column(
                children: [
                  DropdownButtonFormField(
                    value: selectedEducation,
                    decoration: InputDecoration(
                      label: Text("Enter your education"),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20)),
                    ),
                    items: Education.map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(e),
                      ),
                    ).toList(),
                    onChanged: (value) {
                      if (value != null && value.toString().length != 0) {
                        selectedEducation = value;
                      }
                    },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  DropdownButtonFormField(
                    value: selectedJoiningYear,
                    decoration: InputDecoration(
                        label: Text("Enter your joining year"),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20))),
                    items: JoiningYear.map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(e.toString()),
                      ),
                    ).toList(),
                    onChanged: (value) {
                      if (value != null && value.toString().length != 0) {
                        selectedJoiningYear = value;
                      }
                    },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  DropdownButtonFormField(
                    value: selectCity,
                    decoration: InputDecoration(
                        label: Text("Enter your city"),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20))),
                    items: City.map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(e),
                      ),
                    ).toList(),
                    onChanged: (value) {
                      if (value != null && value.toString().length != 0) {
                        selectCity = value;
                      }
                    },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  DropdownButtonFormField(
                    value: selectdPaymeneties,
                    decoration: InputDecoration(
                        label: Text("Enter your payment ties"),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20))),
                    items: PaymentTier.map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(e.toString()),
                      ),
                    ).toList(),
                    onChanged: (value) {
                      if (value != null && value.toString().length != 0) {
                        selectdPaymeneties= value;
                      }
                    },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  TextFormField(
                    controller: enteredAge,
                    decoration: InputDecoration(
                        label: Text("Enter your Age"),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20))),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  DropdownButtonFormField(
                    value: selectedGender,
                    decoration: InputDecoration(
                        label: Text("Enter your Gender"),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20))),
                    items: Gender.map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(e.toString()),
                      ),
                    ).toList(),
                    onChanged: (value) {
                      if (value != null && value.toString().length != 0) {
                        selectedGender = value;
                      }
                    },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  DropdownButtonFormField(
                    value: seletedEverBenched,
                    decoration: InputDecoration(
                        label: Text("Enter your everbenched"),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20))),
                    items: EverBenched.map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(e.toString()),
                      ),
                    ).toList(),
                    onChanged: (value) {
                      if (value != null && value.toString().length != 0) {
                        seletedEverBenched = value;
                      }
                    },
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  TextFormField(
                    controller: enterExperience,
                    decoration: InputDecoration(
                        label: Text("Enter your experiance"),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20))),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                      width: double.infinity,
                      child: ElevatedButton(
                          onPressed: () {
                            postOperation(
                                selectedEducation.toString(),
                                selectedJoiningYear.toString(),
                                selectCity.toString(),
                                selectdPaymeneties.toString(),
                                enteredAge.text.toString(),
                                selectedGender.toString(),
                                seletedEverBenched.toString(),
                                enterExperience.text.toString());
                          },
                          child: Text("Enter")))
                ],
              ))
            ],
          ),
        ),
      ),
    );
  }
}
