List<String> Education = ['Bachelors', 'Masters', 'PHD'];
List<int> JoiningYear = [2017, 2013, 2014, 2016, 2015, 2012, 2018];
List<String> City = ['Bangalore', 'Pune', 'New Delhi'];
List<int> PaymentTier = [3, 1, 2];
var Age; //Here Enter age
List<String> Gender = ['Male', 'Female'];
List<String> EverBenched = ['No', 'Yes'];
var ExperienceInCurrentDomain; //Here enter integer values b/w 0 ,9
