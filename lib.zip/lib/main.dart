import 'package:flutter/material.dart';
import 'package:jcsirhelloworld/screen/enter_screen.dart';

void main(List<String> args) {
  runApp(MaterialApp(home: EnterScreen(),));
}